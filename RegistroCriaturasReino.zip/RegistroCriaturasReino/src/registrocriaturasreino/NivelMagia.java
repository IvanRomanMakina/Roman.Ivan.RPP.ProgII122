package registrocriaturasreino;

public enum NivelMagia {
    BAJO,
    MEDIO,
    ALTO
}
