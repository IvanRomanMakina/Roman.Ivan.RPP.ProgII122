package registrocriaturasreino;

public class RegistroCriaturasReino {

    public static void main(String[] args) {
        
    }
    
}
