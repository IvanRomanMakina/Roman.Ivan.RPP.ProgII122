package restaurante26;

public enum TipoPreparacion {
    FRIA, CALIENTE
}
