package restaurante26;

public interface Preparable {
    void preparar();
}
