package restaurante26;

public class Entrada extends Plato implements Preparable, Decorar{
     private final int cantidadIngredientes;

    public Entrada(String nombre, double precio, TipoPreparacion tipo, int cantidadIngredientes) {
        super(nombre, precio, tipo);
        this.cantidadIngredientes = cantidadIngredientes;
    }

    @Override
    public void preparar() {
        System.out.println("Preparando entrada: " + nombre);
    }

    @Override
    public void decorar() {
        System.out.println("Decorando entrada: " + nombre);
    }

    @Override
    public void mostrarDetalles() {
        System.out.println("Entrada: " + nombre + " - $" + precio +
                " (" + tipo + ") - Ingredientes: " + cantidadIngredientes);
    }
    
}
