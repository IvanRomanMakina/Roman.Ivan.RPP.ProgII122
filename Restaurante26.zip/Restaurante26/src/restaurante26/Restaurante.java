package restaurante26;

import java.util.ArrayList;

public class Restaurante {

    private final ArrayList<Plato> menu = new ArrayList<>();

    public void agregarPlato(Plato plato) throws PlatoDuplicadoException {
        for (Plato p : menu) {
            if (p.getNombre().equalsIgnoreCase(plato.getNombre()) &&
                p.getClass().equals(plato.getClass())) {
                throw new PlatoDuplicadoException("Plato duplicado: " + plato.getNombre());
            }
        }
        menu.add(plato);
    }

    public void mostrarPlatos() {
        for (Plato p : menu) {
            p.mostrarDetalles();
        }
    }

    public void prepararPlato(String nombre) {
        for (Plato p : menu) {
            if (p.getNombre().equalsIgnoreCase(nombre)) {
                if (p instanceof Preparable) {
                    ((Preparable) p).preparar();
                } else {
                    System.out.println("Este plato no se puede preparar.");
                }
                return;
            }
        }
        System.out.println("No existe ese plato.");
    }

    public void decorarPlato(String nombre) {
        for (Plato p : menu) {
            if (p.getNombre().equalsIgnoreCase(nombre)) {
                if (p instanceof Decorar) {
                    ((Decorar) p).decorar();
                } else {
                    System.out.println("Este plato no se puede decorar.");
                }
                return;
            }
        }
        System.out.println("No existe ese plato.");
    }

    public void filtrarPorTipoPreparacion(TipoPreparacion tipo) {
        for (Plato p : menu) {
            if (p.getTipo() == tipo) {
                p.mostrarDetalles();
            }
        }
    }

    public void mostrarPlatosPorTipo(String tipoPlato) {
        for (Plato p : menu) {
            if (p.getClass().getSimpleName().equalsIgnoreCase(tipoPlato)) {
                p.mostrarDetalles();
            }
        }
    }
}
