package restaurante26;

public class Mainn {
    public static void main(String[] args) {

        Restaurante r = new Restaurante();

        try {
            r.agregarPlato(new Entrada("Bruschetta", 1500.0, TipoPreparacion.FRIA, 5));
            r.agregarPlato(new PlatoPrincipal("Asado", 5000.0, TipoPreparacion.CALIENTE, 60));
            r.agregarPlato(new Postre("Tiramisú", 3000, TipoPreparacion.FRIA, true));
        } catch (PlatoDuplicadoException e) {
            System.out.println(e.getMessage());
        }

        r.mostrarPlatos();

        r.prepararPlato("Bruschetta");
        r.decorarPlato("Tiramisú");

        r.filtrarPorTipoPreparacion(TipoPreparacion.FRIA);
        r.mostrarPlatosPorTipo("Entrada");
    }
}
