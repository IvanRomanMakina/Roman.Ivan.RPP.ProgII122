package restaurante26;

public class Postre extends Plato implements Decorar{
    private final boolean tieneAzucar;

    public Postre(String nombre, double precio, TipoPreparacion tipo, boolean tieneAzucar) {
        super(nombre, precio, tipo);
        this.tieneAzucar = tieneAzucar;
    }

    @Override
    public void decorar() {
        System.out.println("Decorando postre: " + nombre);
    }

    @Override
    public void mostrarDetalles() {
        System.out.println("Postre: " + nombre + " - $" + precio +
                " (" + tipo + ") - Contiene azúcar: " + tieneAzucar);
    }
}
