package restaurante26;

public class PlatoPrincipal extends Plato implements Preparable {
    private final int tiempoCoccion; 

    public PlatoPrincipal(String nombre, double precio, TipoPreparacion tipo, int tiempoCoccion) {
        super(nombre, precio, tipo);
        this.tiempoCoccion = tiempoCoccion;
    }

    @Override
    public void preparar() {
        System.out.println("Preparando plato principal: " + nombre);
    }

    @Override
    public void mostrarDetalles() {
        System.out.println("Plato Principal: " + nombre + " - $" + precio +
                           " (" + tipo + ") - Tiempo de cocción: " + tiempoCoccion + " min");
    }
}

