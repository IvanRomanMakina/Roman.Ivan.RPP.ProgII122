package restaurante26;

public abstract class Plato {
    protected String nombre;
    protected double precio;
    protected TipoPreparacion tipo;

    public Plato(String nombre, double precio, TipoPreparacion tipo) {
        this.nombre = nombre;
        this.precio = precio;
        this.tipo = tipo;
    }
    
    public String getNombre() { 
        return nombre; 
    }
    public double getPrecio() { 
        return precio; 
    }
    public TipoPreparacion getTipo() { 
        return tipo; 
    }

    public abstract void mostrarDetalles();
}