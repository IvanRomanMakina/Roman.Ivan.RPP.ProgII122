package restaurante26;

public interface Decorar {
    void decorar();
}
